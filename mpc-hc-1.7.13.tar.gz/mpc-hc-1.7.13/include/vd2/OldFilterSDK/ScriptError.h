#ifndef f_SYLIA_SCRIPTERROR_H
#define f_SYLIA_SCRIPTERROR_H

#include <vd2/plugin/vdvideofilt.h>

typedef ::VDXScriptError			CScriptError;

#endif
