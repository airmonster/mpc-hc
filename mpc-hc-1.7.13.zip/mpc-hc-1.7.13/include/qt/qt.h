#pragma once

namespace QT
{
	#include "QTML.h"
	#include "Movies.h"
	#include "scrap.h"
	#include "ImageCompression.h"
	#include "ImageCodec.h"
	#include "Quickdraw.h"
}