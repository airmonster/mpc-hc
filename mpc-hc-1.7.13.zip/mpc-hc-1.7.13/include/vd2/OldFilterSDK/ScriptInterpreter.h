#ifndef f_SYLIA_SCRIPTINTERPRETER_H
#define f_SYLIA_SCRIPTINTERPRETER_H

#include <vd2/plugin/vdvideofilt.h>

typedef ::VDXScriptValue			CScriptValue;
typedef ::VDXScriptError			CScriptError;
typedef ::VDXScriptObject			CScriptObject;
typedef ::IVDXScriptInterpreter		IScriptInterpreter;

#endif
